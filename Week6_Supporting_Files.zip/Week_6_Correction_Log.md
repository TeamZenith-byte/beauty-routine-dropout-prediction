# Week 6 Correction and Limitations Log

## A. Audit of existing files (13 Nov 2026)
Inspected: repository (public, readable), all delivered Week 1-5 files, Week 5 report text/tables, Week 3 and Week 5 scripts. Not available: the original build sources for the Week 4/5 reports (helper and figure scripts); I audited the finished files instead. I did not push or change anything on GitHub.

| Finding | Action for you |
|---|---|
| Repo `docs/feature_engineering_table_week4.csv` is the OLD version (F01 `price_usd`); corrected file uses `price` | Replace on GitHub |
| Repo `README.md` progress list stale (empty Week 3 line, no Week 4/5/6) | Update |
| Week 4 report stored as `...Report-3.docx` in repo | Rename (optional) |
| Repo Week 1 Final docx is 87,137 bytes vs 87,197 delivered | Decide which is intended |
| Week 5 report, script, readiness table, Week 3 script: identical to repo | None |
| Week 5 `--demo` re-run: exit 0 | None |

Note: the earlier session summary quoted feature counts of 11/8/4; the actual `feature_readiness_table_week5.csv` shows 11 (public data exist, not computed), 9 (need extra info) and 10 (planned, no data). The Week 6 report uses the CSV counts.

## B. Assumptions made
1. Outcome window and definition of "dropped" are not yet fixed; the report gives an example only.
2. Cost ratio of missed dropout vs false alarm is unknown; only arbitrary units are used.
3. Decision criteria in Table 27 are proposed rules, not tested.
4. Rule of thumb of 10-20 events per predictor is a general guideline, not a project result.
5. Model property comparison (Table 18) reflects general algorithm behaviour.

## C. Limitations
No verified labels; proxy public data; pipeline and templates tested only on simulated data; no feature computed on real data; BRFS weights unvalidated; H1-H5 untested; expected small sample; association not causation; Kaggle licence not verified.

## D. Things deliberately NOT done
No performance numbers, rankings, confusion counts, savings or revenue figures. Demo outputs from the Week 6 template are not quoted. No GitHub upload.

## E. Verification limits
Reference links not all opened from my workspace; open each once. LibreOffice pagination differs from Word; TOC page numbers are pre-filled from the PDF and Word will refresh them on open. The Week 6 template was run only with `--demo`, `--demo-grouped`, `--blank-templates` and the real-data refusal gate.
